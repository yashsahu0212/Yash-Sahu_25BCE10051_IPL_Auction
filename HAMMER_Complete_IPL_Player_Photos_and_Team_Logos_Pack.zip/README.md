# HAMMER — Complete IPL Player + Team Asset Pack

This pack fixes the incompleteness of the earlier player-image archive.

It is intentionally a **downloader/asset-builder**, rather than pretending that a small
partial archive is the complete IPL image set.

## What it does

- Visits the official IPL team pages for all 10 current franchises.
- Scrolls the squad area to trigger lazy-loaded player cards.
- Extracts official IPL player headshot URLs.
- Downloads the discovered player images locally.
- Extracts/downloads team logos.
- Reads HAMMER's `data/players.json` when available.
- Reports HAMMER players that do not have an official IPL image.
- Produces manifests so each local image can be mapped deterministically.

## Teams

CSK, DC, GT, KKR, LSG, MI, PBKS, RR, RCB, SRH.

## Run

From this folder:

```powershell
pip install playwright requests
playwright install chromium
python download_ipl_assets.py
```

The generated directory will be:

`HAMMER_IPL_Assets/`

Then copy the resulting:

`HAMMER_IPL_Assets/players/`
`HAMMER_IPL_Assets/teams/`
`HAMMER_IPL_Assets/player_image_manifest.json`
`HAMMER_IPL_Assets/team_logo_manifest.json`

into the HAMMER project.

## Important

The official IPL site does not necessarily provide an image for every historical/auction
player. The script does **not** fabricate missing photographs. It records them in
`download_report.json`.

For HAMMER, use a neutral fallback for players genuinely absent from the official source.

Source:
https://www.iplt20.com/teams
