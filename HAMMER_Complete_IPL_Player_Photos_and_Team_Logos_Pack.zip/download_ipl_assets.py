#!/usr/bin/env python3
"""
HAMMER — Complete IPL Player + Team Asset Downloader

Downloads player headshots and team logos from the official IPL website.
Designed to run locally where the project has internet access.

Requirements:
  Python 3.10+
  pip install playwright requests
  playwright install chromium

Usage:
  python download_ipl_assets.py

Output:
  ./HAMMER_IPL_Assets/
    players/<team-slug>/<player-slug>.png
    teams/<team-slug>.png
    player_image_manifest.json
    team_logo_manifest.json
    download_report.json

Notes:
- The official IPL pages are the source of truth for discovery.
- The script scrolls the squad rail so lazy-loaded player cards are discovered.
- It also reads the project's data/players.json when available and reports any project
  players that could not be mapped to an official IPL image.
- It does not invent or generate player photographs.
"""

import asyncio, json, os, re, sys, unicodedata
from pathlib import Path
from urllib.parse import urljoin, urlparse, parse_qs, unquote

import requests
from playwright.async_api import async_playwright

ROOT = Path(__file__).resolve().parent
PROJECT = ROOT.parent
OUT = ROOT / "HAMMER_IPL_Assets"
PLAYERS_OUT = OUT / "players"
TEAMS_OUT = OUT / "teams"

TEAMS = {
    "csk": ("Chennai Super Kings", "https://www.iplt20.com/teams/chennai-super-kings"),
    "dc": ("Delhi Capitals", "https://www.iplt20.com/teams/delhi-capitals"),
    "gt": ("Gujarat Titans", "https://www.iplt20.com/teams/gujarat-titans"),
    "kkr": ("Kolkata Knight Riders", "https://www.iplt20.com/teams/kolkata-knight-riders"),
    "lsg": ("Lucknow Super Giants", "https://www.iplt20.com/teams/lucknow-super-giants"),
    "mi": ("Mumbai Indians", "https://www.iplt20.com/teams/mumbai-indians"),
    "pbks": ("Punjab Kings", "https://www.iplt20.com/teams/punjab-kings"),
    "rr": ("Rajasthan Royals", "https://www.iplt20.com/teams/rajasthan-royals"),
    "rcb": ("Royal Challengers Bengaluru", "https://www.iplt20.com/teams/royal-challengers-bengaluru"),
    "srh": ("Sunrisers Hyderabad", "https://www.iplt20.com/teams/sunrisers-hyderabad"),
}

def slug(s):
    s = unicodedata.normalize("NFKD", s).encode("ascii", "ignore").decode()
    s = re.sub(r"[^a-zA-Z0-9]+", "-", s).strip("-").lower()
    return s

def normalize_name(s):
    s = s.lower().replace(".", "").replace("'", "")
    s = re.sub(r"\([^)]*\)", "", s)
    s = re.sub(r"[^a-z0-9]+", " ", s).strip()
    aliases = {
        "m s dhoni": "ms dhoni",
        "mohammed siraj": "mohammad siraj",
        "syed khaleel ahmed": "khaleel ahmed",
        "xar patel": "axar patel",
        "xar": "axar",
    }
    return aliases.get(s, s)

def best_src(src, srcset):
    candidates = []
    for raw in [src] + [x.strip().split(" ")[0] for x in (srcset or "").split(",")]:
        if raw and not raw.startswith("data:"):
            candidates.append(raw)
    # Prefer the largest Next image URL.
    for u in reversed(candidates):
        if "_next/image" in u:
            return u
    return candidates[-1] if candidates else None

def decode_next_image(u):
    if not u:
        return None
    if "_next/image" not in u:
        return u
    try:
        q = parse_qs(urlparse(u).query)
        if q.get("url"):
            return unquote(q["url"][0])
    except Exception:
        pass
    return u

def load_project_players():
    candidates = [
        PROJECT / "data" / "players.json",
        PROJECT / "players.json",
    ]
    for p in candidates:
        if p.exists():
            try:
                raw = json.loads(p.read_text(encoding="utf-8"))
                if isinstance(raw, list):
                    return raw
                if isinstance(raw, dict):
                    for key in ("players", "data", "items"):
                        if isinstance(raw.get(key), list):
                            return raw[key]
            except Exception:
                pass
    return []

async def discover():
    found = []
    logos = []
    async with async_playwright() as pw:
        browser = await pw.chromium.launch(headless=True)
        page = await browser.new_page(viewport={"width": 1440, "height": 1000})
        for team_slug, (team_name, url) in TEAMS.items():
            print(f"\n[{team_slug.upper()}] {team_name}")
            await page.goto(url, wait_until="domcontentloaded", timeout=90000)
            await page.wait_for_timeout(2500)

            # Trigger lazy-loaded squad cards.
            for _ in range(18):
                await page.mouse.wheel(0, 1200)
                await page.wait_for_timeout(350)

            # Scroll back up so header logos are available too.
            await page.evaluate("window.scrollTo(0,0)")
            await page.wait_for_timeout(500)

            cards = await page.locator('img[data-testid="squad-card-rail-player-image"]').all()
            for img in cards:
                name = await img.get_attribute("alt")
                src = await img.get_attribute("src")
                srcset = await img.get_attribute("srcset")
                if name:
                    found.append({
                        "team": team_slug,
                        "team_name": team_name,
                        "player_name": name.strip(),
                        "player_slug": slug(name),
                        "image_url": decode_next_image(best_src(src, srcset)),
                        "source_page": url,
                    })

            logo_imgs = await page.locator('img[data-testid*="team-logo-img"]').all()
            for img in logo_imgs:
                alt = await img.get_attribute("alt")
                src = await img.get_attribute("src")
                srcset = await img.get_attribute("srcset")
                if alt:
                    logos.append({
                        "team": team_slug,
                        "team_name": team_name,
                        "alt": alt,
                        "image_url": decode_next_image(best_src(src, srcset)),
                        "source_page": url,
                    })

        await browser.close()

    # Deduplicate by team + normalized player name.
    players = {}
    for x in found:
        players[(x["team"], normalize_name(x["player_name"]))] = x
    # Deduplicate logos by team.
    logo_map = {}
    for x in logos:
        if x["team"] not in logo_map:
            logo_map[x["team"]] = x

    return list(players.values()), list(logo_map.values())

def download(url, path):
    if not url:
        return False, "missing-url"
    path.parent.mkdir(parents=True, exist_ok=True)
    try:
        r = requests.get(url, timeout=45, headers={
            "User-Agent": "HAMMER IPL Asset Downloader/1.0"
        })
        r.raise_for_status()
        data = r.content
        if len(data) < 200:
            return False, "response-too-small"
        path.write_bytes(data)
        return True, f"{len(data)} bytes"
    except Exception as e:
        return False, str(e)

def main():
    OUT.mkdir(parents=True, exist_ok=True)
    players, logos = asyncio.run(discover())

    project_players = load_project_players()
    project_names = []
    for p in project_players:
        if isinstance(p, dict):
            n = p.get("name") or p.get("player_name") or p.get("playerName")
            if n:
                project_names.append(n)

    player_manifest = []
    downloaded = 0
    failed = 0

    for p in players:
        target = PLAYERS_OUT / p["team"] / f'{p["player_slug"]}.png'
        ok, result = download(p["image_url"], target)
        p["local_file"] = str(target.relative_to(OUT)).replace("\\", "/") if ok else None
        p["download"] = result
        player_manifest.append(p)
        downloaded += int(ok)
        failed += int(not ok)
        print(("OK   " if ok else "FAIL ") + p["team"] + " / " + p["player_name"])

    logo_manifest = []
    for t in logos:
        target = TEAMS_OUT / t["team"] / "logo.png"
        ok, result = download(t["image_url"], target)
        t["local_file"] = str(target.relative_to(OUT)).replace("\\", "/") if ok else None
        t["download"] = result
        logo_manifest.append(t)

    # Match project players to discovered official photos.
    by_name = {}
    for p in player_manifest:
        by_name.setdefault(normalize_name(p["player_name"]), []).append(p)

    missing_project = []
    for n in project_names:
        if normalize_name(n) not in by_name:
            missing_project.append(n)

    report = {
        "source": "Official IPL website (iplt20.com)",
        "teams_discovered": len(logos),
        "player_images_discovered": len(player_manifest),
        "player_images_downloaded": downloaded,
        "player_images_failed": failed,
        "team_logos_discovered": len(logo_manifest),
        "team_logos_downloaded": sum(1 for x in logo_manifest if x.get("local_file")),
        "project_players_checked": len(project_names),
        "project_players_missing_official_image": missing_project,
    }

    (OUT / "player_image_manifest.json").write_text(
        json.dumps(player_manifest, indent=2, ensure_ascii=False), encoding="utf-8"
    )
    (OUT / "team_logo_manifest.json").write_text(
        json.dumps(logo_manifest, indent=2, ensure_ascii=False), encoding="utf-8"
    )
    (OUT / "download_report.json").write_text(
        json.dumps(report, indent=2, ensure_ascii=False), encoding="utf-8"
    )

    print("\n" + "=" * 70)
    print(json.dumps(report, indent=2, ensure_ascii=False))
    print("=" * 70)
    print("\nIMPORTANT: A missing official image is reported as missing; no fake image is generated.")

if __name__ == "__main__":
    main()
