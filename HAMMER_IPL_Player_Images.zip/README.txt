HAMMER — IPL player image package

Source: saved Chennai Super Kings page from IPLT20.com.
The HTML contained 4 player image cards at the time it was saved: Khaleel Ahmed, Dewald Brevis, Rahul Chahar, and Mukesh Choudhary.

The URLs in players.json point to IPLT20 image endpoints. The included downloader can fetch the images on a machine with internet access.

IMPORTANT: IPL/BCCI image-use terms may restrict reuse. The official 2026 image terms found on IPLT20 grant licensed media images for bona fide editorial use and restrict commercial use. Verify that your competition/demo's intended use is permitted before publicly distributing these images.


Also included: download_all_ipl_players.py — downloads the current squad player images for all 10 IPL team pages into ./ipl_players/<TEAM>/. Run it locally with Python 3 and internet access.
