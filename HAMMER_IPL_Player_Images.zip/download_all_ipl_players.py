import os,re,html,json,requests
from urllib.parse import urljoin

TEAMS={
'CSK':'chennai-super-kings','DC':'delhi-capitals','GT':'gujarat-titans','KKR':'kolkata-knight-riders','LSG':'lucknow-super-giants','MI':'mumbai-indians','PBKS':'punjab-kings','RR':'rajasthan-royals','RCB':'royal-challengers-bengaluru','SRH':'sunrisers-hyderabad'}
BASE='https://www.iplt20.com'; OUT='ipl_players'; os.makedirs(OUT,exist_ok=True)
H={'User-Agent':'Mozilla/5.0'}
all_players=[]
for code,slug in TEAMS.items():
    print('\n'+code)
    page=requests.get(f'{BASE}/teams/{slug}',headers=H,timeout=30); page.raise_for_status(); s=page.text
    blocks=re.findall(r'<img[^>]*data-testid="squad-card-rail-player-image"[^>]*>',s)
    seen=set()
    for b in blocks:
        nm=re.search(r'alt="([^"]+)"',b); su=re.search(r'srcset="([^"]+)"',b)
        if not nm or not su: continue
        name=html.unescape(nm.group(1)).strip(); url=html.unescape(su.group(1)).split()[0]
        if name in seen: continue
        seen.add(name)
        safe=re.sub(r'[^A-Za-z0-9._-]+','_',name).strip('_')
        folder=os.path.join(OUT,code); os.makedirs(folder,exist_ok=True)
        path=os.path.join(folder,safe+'.jpg')
        try:
            r=requests.get(url,headers=H,timeout=30); r.raise_for_status(); open(path,'wb').write(r.content)
            print('OK',name)
        except Exception as e: print('FAIL',name,e)
        all_players.append({'name':name,'team':code,'image_url':url,'local_path':path})
json.dump(all_players,open('ipl_players.json','w',encoding='utf-8'),indent=2,ensure_ascii=False)
print(f'\nDone: {len(all_players)} player records')
