import json, os, re, html, requests
from urllib.parse import urlparse, parse_qs

BASE='https://www.iplt20.com'
PAGE='https://www.iplt20.com/teams/chennai-super-kings'
OUT='players'
os.makedirs(OUT, exist_ok=True)

headers={'User-Agent':'Mozilla/5.0'}
s=requests.get(PAGE,headers=headers,timeout=30).text
blocks=re.findall(r'<img[^>]*data-testid="squad-card-rail-player-image"[^>]*>',s)
seen=set(); players=[]
for b in blocks:
    m=re.search(r'alt="([^"]+)"',b); u=re.search(r'srcset="([^"]+)"',b)
    if not m or not u: continue
    name=html.unescape(m.group(1)).strip()
    url=html.unescape(u.group(1)).split()[0]
    if name in seen: continue
    seen.add(name); players.append((name,url))

print(f'Found {len(players)} player image(s)')
for name,url in players:
    safe=re.sub(r'[^A-Za-z0-9._-]+','_',name).strip('_')
    path=os.path.join(OUT,safe+'.jpg')
    try:
        r=requests.get(url,headers=headers,timeout=30); r.raise_for_status()
        open(path,'wb').write(r.content); print('OK',name)
    except Exception as e: print('FAIL',name,e)

json.dump([{'name':n,'image_url':u} for n,u in players],open('players.json','w',encoding='utf-8'),indent=2,ensure_ascii=False)
print('Done. Images are in ./players/')
